from setuptools import setup 

setup (
    name = 'vsearch',
    version='1.2',
    description= ' my first py module', 
    author = 'babu', 
    author_email='benkaimugul@gmail.com', 
    url = 'kipkulei.com', 
    py_modules=[ 'vsearch'],


)