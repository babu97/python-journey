from setuptools import setup 

setup (
    name = 'vsearch1',
    version='1.4',
    description= ' my first py module', 
    author = 'babu', 
    author_email='benkaimugul@gmail.com', 
    url = 'kipkule.space', 
    py_modules=[ 'vsearch1'],


)