from setuptools import setup 

setup (
    name = 'vsearch',
    version='1.3',
    description= ' my first py module', 
    author = 'babu', 
    author_email='benkaimugul@gmail.com', 
    url = 'kipkule.space', 
    py_modules=[ 'vsearch'],


)