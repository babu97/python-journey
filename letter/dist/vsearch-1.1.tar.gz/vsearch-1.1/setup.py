from setuptools import setup 

setup (
    name = 'vsearch',
    version='1.1',
    description= ' The Head first Python search tools', 
    author = 'babu', 
    author_email='benkaimugul@gmail.com', 
    url = 'headfirstlabs.com', 
    py_modules=[ 'vsearch'],


)