from distutils.core import setup

setup(

name= 'nester',
version='1.0.1',
py_modules=['nester'],
author='hfpython',
author_email='benkaimugul@gmail.com',
url= 'babu.com',
description='A simpe printer of nested lists',
)